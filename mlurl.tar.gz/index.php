<?php
require_once("MlurlPlugin.inc.php");
return new MlurlPlugin();
?>
